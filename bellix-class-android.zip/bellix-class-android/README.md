# Bellix Class — pacote para gerar o APK Android

Este pacote usa o mesmo método que você já usou no RankTarefa: Capacitor + GitHub Actions
(sem precisar de Ionic Appflow nem instalar Android Studio no seu computador).

## Passo a passo

1. Crie um repositório novo no GitHub (pode ser privado) e suba todos os arquivos desta pasta
   (incluindo a pasta oculta `.github`).
2. No GitHub, vá em **Actions** → escolha o workflow **"Build Android APK"** → **Run workflow**.
3. Espere o build terminar (uns 3 a 5 minutos).
4. Baixe o APK gerado em **Artifacts** (arquivo `bellix-class-debug-apk`), dentro da execução do workflow.
5. Transfira o `.apk` para o celular Android e instale (é preciso permitir "instalar de fontes desconhecidas"
   na primeira vez).

## Sobre o app em si

- O arquivo `www/index.html` é o app completo (turmas, alunos, tarefas, entregas).
- Os dados ficam salvos no armazenamento local do próprio celular (dentro do app),
  então cada professor(a) que instalar o APK terá seus próprios dados, separados dos seus.
- Dentro do app, em **Configurações**, tem o botão **"Limpar tudo e começar do zero"** —
  é o que cada professor(a) vai usar para tirar os dados de exemplo e cadastrar a turma real dele(a).
- Também tem exportar/importar backup em JSON, caso queira guardar uma cópia de segurança
  ou trocar de aparelho sem perder os dados.

## Se quiser publicar na Play Store depois

Esse workflow gera um APK de **debug**, bom para testar no seu celular e distribuir manualmente.
Para publicar na Play Store, o processo muda um pouco (build "release" assinado com uma chave própria).
Me avise quando chegar nessa etapa que eu preparo esse passo também.
